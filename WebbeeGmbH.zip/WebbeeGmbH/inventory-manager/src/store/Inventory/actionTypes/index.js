
/*
 * action types
 */
export var VIEW_ALL = 'VIEW_ALL';
export var ADD_TYPE = 'ADD_TYPE';
export var DELETE_TYPE = 'DELETE_TYPE';
export var EDIT_TYPE = 'DELETE_TYPE';


export default{
  VIEW_ALL : VIEW_ALL,
  ADD_TYPE : ADD_TYPE,
  DELETE_TYPE : DELETE_TYPE,
  EDIT_TYPE : DELETE_TYPE
}