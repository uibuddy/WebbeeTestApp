
var defaultState={
    "objectType":"Chainsaws",
    "objectTitle":'Blue Max(14") 8- Amp Electric Chain Saw',
    fields:{
        model:'Blue Max(14") 8- Amp Electric Chain Saw',
        type:"Electric",
        grade:"Professional",
        brand:"Blue Max",
        bar:"14",
        date:"Tue May 23 2020 18:43:25 GMT+0530 (India Standard Time)",
        quantity:"6"
    }
}
const inventoryIntialState=[defaultState, defaultState];
export{inventoryIntialState} ;
export default inventoryIntialState;